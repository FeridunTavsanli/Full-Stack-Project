package com.repsy.objectstorage;

import com.repsy.api.service.StorageStrategy;

import java.io.InputStream;

public class ObjectStorageService implements StorageStrategy {
    @Override
    public void store(String path, InputStream data) {
        // TODO: Use MinIO Java SDK here
        System.out.println("Storing to MinIO: " + path);
    }

    @Override
    public InputStream retrieve(String path) {
        // TODO: Use MinIO Java SDK here
        return null;
    }
}
